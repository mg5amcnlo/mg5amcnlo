#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <vector>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>

// Access to Pythia8
#include "Pythia8/Pythia.h"
#include "Pythia8/Event.h"

// LHEF class to parse Les Houches events (as testing case).
//#include "LHEF.h"

using namespace std;

// Small values used to cut off momenta
const double TINY      = 1e-15;
const double TINYMASS  = 1e-8;

double doStuff(Pythia8::Event* evt) {
	return 1.0;
}

extern "C" {   
//Fortran interface

    void get_py8_wgt_(const double & eCM, const double * p, const int & npart,
			      const int * id, const int * colors_one, const int * colors_two, const int * ist
				  ,double & py8weight){
    // Instantiate the corresponding event.
    Pythia8::Event* evt = new Pythia8::Event();
	evt->init("Temporary event",0);

    for (int i=0; i<npart*5; i=i+5) {
      // Store information in a State.
      double pup0 = (abs(p[i+0]) < TINY) ? 0.: p[i+0];
      double pup1 = (abs(p[i+1]) < TINY) ? 0.: p[i+1];
      double pup2 = (abs(p[i+2]) < TINY) ? 0.: p[i+2];
      double pup3 = (abs(p[i+3]) < TINY) ? 0.: p[i+3];
      double pup4 = (abs(p[i+4]) < TINYMASS) ? 0.: p[i+4];

     cout<<id[i/5]<<endl;
     cout<<ist[i/5]<<endl;
     cout<<colors_one[i/5]<<endl;
     cout<<colors_two[i/5]<<endl;
     cout<<pup0<<";"<<pup1<<";"<<pup2<<";"<<pup3<<";"<<pup4<<endl;
     evt->append(Pythia8::Particle( id[i/5], ist[i/5],0,0,0,0, 
				                     colors_one[i/5], colors_two[i/5],
                                     pup0, pup1, pup2, pup3, pup4,0.0,9.0));
    }
	py8weight = doStuff(evt);
    delete evt;
  }
}

