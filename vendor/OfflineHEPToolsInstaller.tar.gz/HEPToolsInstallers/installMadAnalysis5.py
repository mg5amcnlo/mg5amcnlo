#! /usr/bin/env python
import re
import sys
import os
import logging

pjoin = os.path.join

_zlib_path     = None
_ma5_path      = None
_mg5_path      = None
_delphes3_path = None
_fastjet_path  = None
_logging_level = logging.INFO
MA5_further_install = True

args = sys.argv[1:]

help_msg = \
""" 
Call this python script with the following mandatory arguments:
   --zlib=<zlib_path>               : Path to the zlib library to employ.
   --ma5_path=<ma5_install_path>    : Path to the already untarred MA5 installation
   --mg5_path=<mg5_root_dir>        : Path of MG5 installation
Optional dependency:
   --delphes3=<delphes3_path>       : Path to the Delphes3 installation to be used in MA5.
   --fastjet=<fastjet_dir>          : Path to fastjet
   --no_MA5_further_install         : Prevent MA5 to install further tools
   --logging=<int>                  : Specify MA5 logger level
"""

def failed_installation():
    print "INSTALLATION STATUS: FAILED"
    sys.exit(1)

for arg in args:
    try:
        option, value = arg.split('=')
    except ValueError:
        option = arg
        value = None
    if option == '--zlib':
        _zlib_path=value
    elif option == '--ma5_path':
        _ma5_path=value
    elif option == '--mg5_path':
        _mg5_path=value
    elif option == '--delphes3':
        _delphes3_path=value
    elif option == '--logging':
        _logging_level=int(value)
    elif option == '--fastjet':
        _fastjet_path=value
    elif option == '--no_MA5_further_install':
        MA5_further_install = False
    else:
        print "Option '%s' not reckognized."%option
        print help_msg
        failed_installation()
        sys.exit(1)

if _zlib_path is None or _ma5_path is None:
        print help_msg
        failed_installation()
        sys.exit(1)

MA5_dependency_file_specifier = pjoin(_ma5_path,'madanalysis','input','installation_options.dat')

# For now, MA5 does not support external versions of Delphes, so that it will ignore it
# and reinstall its own version

if any(not dependency is None for dependency in [_delphes3_path, _fastjet_path, _zlib_path]):
    new_dependencies = []
    for line in open(MA5_dependency_file_specifier):
        if False and 'delphes_includes' in line and _delphes3_path:
            new_dependencies.append("delphes_includes = %s\n"%_delphes3_path)
        elif False and 'delphes_libs' in line and _delphes3_path:
            new_dependencies.append("delphes_libs = %s\n"%_delphes3_path)
        elif 'fastjet_bin_path' in line and _fastjet_path:
            new_dependencies.append("fastjet_bin_path = %s\n"%_fastjet_path)
        elif 'zlib_includes' in line and _zlib_path:
            new_dependencies.append("zlib_includes = %s\n"%pjoin(_zlib_path,'include'))
        elif 'zlib_libs' in line and _zlib_path:
            new_dependencies.append("zlib_libs = %s\n"%pjoin(_zlib_path,'lib'))
        else:
            new_dependencies.append(line)
    open(MA5_dependency_file_specifier,'w').write(''.join(new_dependencies))

# Make sure MA5 is accessible
sys.path.insert(0, _ma5_path)

# Make sure 'MA5_BASE' is available in the environnment variables
if 'MA5_BASE' not in os.environ:
    os.environ['MA5_BASE']=_ma5_path

# Now try to import it.
print ">> Attempting to start MA5 and check the availability of its dependencies..."
try:
    from madanalysis.interpreter.ma5_interpreter import MA5Interpreter
    MA5_interpreter = MA5Interpreter(_ma5_path,LoggerLevel=_logging_level,no_compilation=True)
except Exception as e:
    print "Error: Could not import/start MadAnalysis5 python module: %s."%str(e)
    failed_installation()
    sys.exit(1)

if not MA5_further_install:
    # Now trigger the final compilation of SampleAnalyzer
    try:
        if not MA5_interpreter.compile():
            raise Exception('FailedCompilation')
    except Exception as e:
        print "Error: MadAnalysis5 failed to compile SampleAnalyzer:\n %s"%str(e)
        failed_installation()
    print "INSTALLATION STATUS: SUCCESS"
    sys.exit(0)

if _delphes3_path is None:
    print ">> Delphes dependency not specified to the installer. Now asking MadAnalysis5 to install it for us... "
else:
    print ">> Delphes dependency specified but MadAnalysis5 needs to install its own version. Installing it now..."

try:
    if not MA5_interpreter.install('delphes'):
        raise Exception('FailedInstallation')
except Exception as e:
    print "Error: MadAnalysis5 failed installing delphes:\n %s"%str(e)
    failed_installation()

# Pre-install basics MadAnalysis tools
print ">> Installing the PAD tool for MA5 recasting... "
try:
    if not MA5_interpreter.install('PAD'):
        raise Exception('FailedInstallation')
except Exception as e:
    print "Error: MadAnalysis5 failed installing PAD:\n %s"%str(e)
    failed_installation()

print ">> Installing delphesMA5tune for some features of MadAnalysis5 recasting... "
try:
    if not MA5_interpreter.install('delphesMA5tune'):
        raise Exception('FailedInstallation')
except Exception as e:
    print "MadAnalysis5 failed installing delphesMA5tune:\n %s"%str(e)
    failed_installation()

print ">> Installing PADForMA5tune for some features of MadAnalysis5 recasting... "
try:
    if not MA5_interpreter.install('PADForMA5tune'):
        raise Exception('FailedInstallation')
except Exception as e:
    print "Error: MadAnalysis5 failed installing PADForMA5tune:\n %s"%str(e)
    failed_installation()

# Now trigger the final compilation of SampleAnalyzer
try:
    if not MA5_interpreter.compile():
        raise Exception('FailedCompilation')
except Exception as e:
    print "Error: MadAnalysis5 failed to compile SampleAnalyzer:\n %s"%str(e)
    failed_installation()

print ">> Successful installation of MadAnalysis5."

# Write a file to indicate the status of the installation
print "INSTALLATION STATUS: SUCCESS"
