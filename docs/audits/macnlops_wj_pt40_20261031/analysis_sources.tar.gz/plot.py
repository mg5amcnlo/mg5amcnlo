#!/usr/bin/env python3
"""Reproduce the paired25/40GeV first/full-shower Wj analysis comparison."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

BASE=Path(__file__).resolve().parent
OUT=BASE/'plots'
EDGES=np.arange(0.,102.,2.)
TRANSFER_EDGES=np.arange(0.,105.,5.)
CURVES=[('source','Source','#222222','-'),('veto','S veto only','#d95f02','--'),
        ('removal','H removal only','#1b9e77','-.'),('matched','MAcNLOPS','#2166ac','-')]
STAGES=[('first','First emission'),('full','Full shower')]
N=1000000
JOBS=50

def serial(value):
    if isinstance(value,np.ndarray): return serial(value.tolist())
    if isinstance(value,(float,np.floating)): return float(value) if np.isfinite(value) else None
    if isinstance(value,(int,np.integer)): return int(value)
    if isinstance(value,dict): return {k:serial(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)): return [serial(x) for x in value]
    return value

def chunk_hist(x,w,mask,edges):
    x=x.reshape(JOBS,-1);w=w.reshape(JOBS,-1);mask=mask.reshape(JOBS,-1)
    return np.array([np.histogram(a[m],bins=edges,weights=b[m])[0]
                     for a,b,m in zip(x,w,mask)])

def hist_error(h):
    return np.sqrt(JOBS/(JOBS-1)*np.sum((h-h.mean(axis=0))**2,axis=0))

def ratio(x,y):
    """Conditional paired delta-method errors; rows are common source chunks."""
    X,Y=x.sum(axis=0),y.sum(axis=0)
    r=np.divide(Y,X,out=np.full_like(X,np.nan,dtype=float),where=X!=0)
    influence=np.divide(y-r*x,X,out=np.full_like(x,np.nan,dtype=float),where=X!=0)
    err=np.sqrt(JOBS/(JOBS-1)*np.sum(influence**2,axis=0))
    return r,err

def get_data():
    first=np.load(BASE/'first/events.npz')
    full=np.load(BASE/'full/full_events.npz')
    assert np.array_equal(first['source_index'],np.arange(N))
    assert np.array_equal(full['source_index'],np.arange(N))
    assert np.array_equal(first['nominal'],full['nominal'])
    assert np.array_equal(first['macnlops'],full['macnlops'])
    assert np.array_equal(first['is_h'],full['is_h'])
    return {'first':first,'full':full}

def weights(d):
    w,m,h=d['nominal'],d['macnlops'],d['is_h']
    return dict(source=w,veto=np.where(h,w,m),removal=np.where(h,m,w),matched=m)

def build(data):
    result={}
    chunks={}
    for stage,d in data.items():
        result[stage]={};chunks[stage]={}
        for cut in (25,40):
            selected=d[f'selected{cut}'];x=d['fid_recoil'];curves=weights(d)
            h={name:chunk_hist(x,w,selected,EDGES) for name,w in curves.items()}
            t={name:chunk_hist(x,w,selected,TRANSFER_EDGES) for name,w in curves.items()}
            S=t['source']-t['veto'];H=t['removal']-t['source']
            rr,ee=ratio(S,H)
            r={name:dict(sum=a.sum(axis=0),error=hist_error(a)) for name,a in h.items()}
            for name in r:
                r[name]['ratio'],r[name]['ratio_error']=ratio(h['source'],h[name])
            mask=selected&(x>=5)&(x<20)
            all25=selected
            scope={}
            for key,m in [('5_20',mask),('selected_total',all25)]:
                c={name:np.where(m,w,0).reshape(JOBS,-1).sum(axis=1) for name,w in curves.items()}
                s=c['source']-c['veto'];hh=c['removal']-c['source']
                hr,he=ratio(s[:,None],hh[:,None])
                mr,me=ratio(c['source'][:,None],c['matched'][:,None])
                scope[key]=dict(events=int(np.count_nonzero(m)),source_pb=float(c['source'].sum()),
                    matched_pb=float(c['matched'].sum()),S_pb=float(s.sum()),H_pb=float(hh.sum()),
                    H_over_S=float(hr[0]),H_over_S_chunk_error=float(he[0]),
                    matched_over_source_minus1=float(mr[0]-1),matched_over_source_chunk_error=float(me[0]))
                chunks[stage].setdefault(cut,{})[key]=dict(S=s,H=hh,source=c['source'],matched=c['matched'])
            result[stage][cut]=dict(selected_events=int(selected.sum()),curves=r,scopes=scope,
                transfers=dict(S=S.sum(axis=0),S_error=hist_error(S),H=H.sum(axis=0),H_error=hist_error(H),
                               H_over_S=rr,H_over_S_error=ee))
    paired={}
    for stage in data:
        paired[stage]={}
        for scope in ['5_20','selected_total']:
            influences=[];rs=[]
            for cut in [25,40]:
                c=chunks[stage][cut][scope];r=c['H'].sum()/c['S'].sum();rs.append(float(r))
                influences.append((c['H']-r*c['S'])/c['S'].sum())
            delta=influences[1]-influences[0]
            paired[stage][scope]=dict(H_over_S_40_minus25=rs[1]-rs[0],
                paired_chunk_error=float(np.sqrt(JOBS/(JOBS-1))*np.linalg.norm(delta)))
    for cut in [25,40]:
        paired[f'full_minus_first_cut{cut}']={}
        for scope in ['5_20','selected_total']:
            influences=[];rs=[]
            for stage in ['first','full']:
                c=chunks[stage][cut][scope];r=c['H'].sum()/c['S'].sum();rs.append(float(r))
                influences.append((c['H']-r*c['S'])/c['S'].sum())
            delta=influences[1]-influences[0]
            paired[f'full_minus_first_cut{cut}'][scope]=dict(H_over_S_full_minus_first=rs[1]-rs[0],
                paired_chunk_error=float(np.sqrt(JOBS/(JOBS-1))*np.linalg.norm(delta)))
    return result,paired

def footer(fig):
    fig.text(.5,.016,'Same 1M original production events; matching weights, source and shower settings unchanged. '
             'Cuts applied separately at each stage. No fiducial/range renormalization.',ha='center',fontsize=8)
    fig.text(.5,.003,'Bands: conditional 50-chunk sampling errors. Hard integration, channel beta and native ISR-envelope uncertainties excluded.',ha='center',fontsize=8)

def four_weight_page(pdf,result):
    fig=plt.figure(figsize=(12,10));outer=fig.add_gridspec(2,2,hspace=.27,wspace=.2)
    for row,cut in enumerate([25,40]):
        for col,(stage,label) in enumerate(STAGES):
            cell=outer[row,col].subgridspec(2,1,height_ratios=[3,1],hspace=.04)
            ax=fig.add_subplot(cell[0]);ra=fig.add_subplot(cell[1],sharex=ax)
            info=result[stage][cut];curves=info['curves'];width=np.diff(EDGES);center=(EDGES[1:]+EDGES[:-1])/2
            precise=(curves['source']['sum']>0)&(curves['source']['error']<.25*np.abs(curves['source']['sum']))
            ratio_values=[]
            for name,title,color,line in CURVES:
                ax.stairs(curves[name]['sum']/width,EDGES,color=color,ls=line,lw=1.2,label=title)
                if name!='source':
                    values=np.where(precise,curves[name]['ratio'],np.nan)
                    ratio_values.extend(values[np.isfinite(values)])
                    ra.plot(center,values,color=color,ls=line,lw=1.)
            band=curves['matched'];ra.fill_between(center,np.where(precise,band['ratio']-band['ratio_error'],np.nan),np.where(precise,band['ratio']+band['ratio_error'],np.nan),color='#2166ac',alpha=.17)
            values=np.concatenate([curves[name]['sum']/width for name,_,_,_ in CURVES])
            if np.all(values>0):
                ax.set_yscale('log');ax.set_ylim(.75*values.min(),1.4*values.max())
            else:ax.set_yscale('symlog',linthresh=.02,linscale=.6)
            ax.set_ylabel(r'$d\sigma/dp_T(W+j_1)$ [pb/GeV]');ra.set_ylabel('/source')
            ra.axhline(1,color='black',lw=.7)
            if ratio_values:ra.set_ylim(min(.95,min(ratio_values)-.02),max(1.05,max(ratio_values)+.02))
            for a in [ax,ra]:a.set_xlim(0,100);a.axvspan(5,20,color='gold',alpha=.1);a.grid(alpha=.18)
            ax.tick_params(labelbottom=False);ra.set_xlabel(r'$p_T(W+j_1^{\rm fid})$ [GeV]')
            ax.set_title(f'{label}; jet $p_T>{cut}$ GeV, $|y|<4.5$',fontsize=10)
            q=info['scopes']['5_20']
            ax.text(.97,.92,f"5–20 GeV matched/source−1\n{100*q['matched_over_source_minus1']:+.2f}% ± {100*q['matched_over_source_chunk_error']:.2f}%",transform=ax.transAxes,ha='right',va='top',fontsize=8)
            if row==0 and col==0:ax.legend(fontsize=8,frameon=False,loc='lower left')
    fig.suptitle('W+jet: analysis jet threshold 25 → 40 GeV, anti-kT R=0.5\nOriginal pre-gluon-fix production epoch; generation jet cut 20 GeV',fontsize=12)
    footer(fig);fig.subplots_adjust(top=.9,bottom=.08);pdf.savefig(fig)
    fig.savefig(OUT/'wj_pt40_four_weights.png',dpi=150);plt.close(fig)

def transfer_page(pdf,result):
    fig,axes=plt.subplots(2,2,figsize=(12,9),gridspec_kw={'height_ratios':[1.5,1]},sharex='col')
    center=(TRANSFER_EDGES[:-1]+TRANSFER_EDGES[1:])/2;width=np.diff(TRANSFER_EDGES)
    for col,(stage,label) in enumerate(STAGES):
        ax,ra=axes[:,col]
        for cut,line in [(25,'-'),(40,'--')]:
            t=result[stage][cut]['transfers']
            for name,color,title in [('S','#d95f02','Signed S-veto'),('H','#1b9e77','H-removal')]:
                ax.stairs(t[name]/width,TRANSFER_EDGES,color=color,ls=line,lw=1.3,label=f'{title}; jet > {cut} GeV')
            ra.plot(center,t['H_over_S'],color='black' if cut==25 else '#2166ac',ls=line,label=f'Jet > {cut} GeV')
            ra.fill_between(center,t['H_over_S']-t['H_over_S_error'],t['H_over_S']+t['H_over_S_error'],color='black' if cut==25 else '#2166ac',alpha=.12)
        ax.set_title(label);ax.axhline(0,color='black',lw=.6);ax.set_ylabel('Signed transfer [pb/GeV]')
        ra.axhline(1,color='black',lw=.7);ra.set_ylabel('H removal / net S veto');ra.set_xlabel(r'$p_T(W+j_1^{\rm fid})$ [GeV]')
        ra.set_ylim(.25,1.35)
        for a in [ax,ra]:a.set_xlim(0,100);a.axvspan(5,20,color='gold',alpha=.1);a.grid(alpha=.18)
        if col==0:ax.legend(fontsize=8,frameon=False);ra.legend(fontsize=8,frameon=False)
        annotations=[]
        for cut in [25,40]:
            q=result[stage][cut]['scopes']['5_20']
            annotations.append(f"Jet > {cut} GeV: H/S = {q['H_over_S']:.4f} ± {q['H_over_S_chunk_error']:.4f}")
        ax.text(.97,.72 if col==0 else .97,'5–20 GeV\n'+'\n'.join(annotations),transform=ax.transAxes,ha='right',va='top',fontsize=8)
    fig.suptitle('W+jet: signed transfer balance under the 25/40 GeV analysis cuts\nThe highlighted 5–20 GeV interval is recoil, not jet transverse momentum',fontsize=12)
    footer(fig);fig.subplots_adjust(top=.89,bottom=.09,hspace=.08,wspace=.22);pdf.savefig(fig)
    fig.savefig(OUT/'wj_pt40_transfers.png',dpi=150);plt.close(fig)

def main():
    OUT.mkdir(exist_ok=True)
    data=get_data();result,paired=build(data)
    record=dict(events=N,source_chunks=JOBS,epoch='Original pre-gluon-fix1M Wj production; only analysis threshold changes.',
        definition='anti-kT R0.5, at least one jet withpT>25/40GeV and|y|<4.5. Recoil W+leadingpassingjet.',
        units='pb; all original signed weights retained without survivor/fiducial/range renormalization.',
        errors='Conditional50-chunk paired delta-method errors; common first/full source indexing.',
        edges=EDGES,transfer_edges=TRANSFER_EDGES,stages=result,paired=paired)
    (OUT/'wj_pt40_histograms.json').write_text(json.dumps(serial(record),separators=(',',':'),allow_nan=False)+'\n')
    with PdfPages(OUT/'wj_analysis_pt40.pdf') as pdf:
        four_weight_page(pdf,result);transfer_page(pdf,result)
    print('Wrote2-page PDF,2PNG previews andcompact histogramJSON')

if __name__=='__main__':main()
