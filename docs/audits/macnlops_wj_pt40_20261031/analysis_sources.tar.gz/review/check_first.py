"""Independent 25/40 first-emission check using at most two QCD jets."""
from pathlib import Path
import json
import numpy as np

BASE = Path('/export/slow1/rikkert/macnlops_native_ir_jets_1M_20261031')
HERE = Path(__file__).resolve().parent


def ratio(x, y):
    X, Y = float(x.sum()), float(y.sum())
    r = Y/X if X else None
    influence = (y-r*x)/X if X else np.zeros(len(x))
    n = len(x)
    return dict(S_pb=X, H_pb=Y, net_pb=Y-X, ratio=r,
                error=float(np.sqrt(n/(n-1))*np.linalg.norm(influence)) if n > 1 and X > 0 and Y > 0 else None), influence


def main():
    old = np.load(BASE/'results/Wj_run_1M_native_ir_jets_lhe.npz')
    names = list(old['observable_names'])
    obs = old['observables']
    get = lambda name: obs[:, names.index(name)]
    central_raw_leader = np.abs(get('jet1_y')) < 4.5
    central_pt = np.where(central_raw_leader, get('jet1_pt'), get('primary_scale'))
    fid25 = get('fiducial') > .5
    masks = {25: fid25, 40: fid25 & (central_pt > 40.)}
    recoil = get('fid_primary_scale')
    w, m, h = old['nominal'], old['macnlops'], old['is_h']
    assert len(w) == 1000000
    weights = dict(source=w, matched=m, veto=np.where(h, w, m), removal=np.where(h, m, w))
    x = np.where(~h, w-m, 0.)
    y = np.where(h, m-w, 0.)
    report = dict(method='Independent first-emission identity: the old endpoint has at most two QCD jets. When its raw leading jet lies outside the rapidity cut and a central jet exists, transverse momentum conservation makes the central jet pT equal the old raw W+leading-jet recoil. The leading qualifying jet otherwise stays unchanged between thresholds.',
                  limits='Requires first-emission endpoint multiplicity and transverse conservation; not used for full showers. Independent exact reclustering is checked when its output becomes available.',
                  events=len(w), cuts={}, paired_cut_changes={})
    components = {}
    for cut, selection in masks.items():
        scopes = {}
        for name, inrange in [('all_selected', np.ones(len(w), dtype=bool)), ('recoil5_20', (recoil >= 5) & (recoil < 20))]:
            mask = selection & inrange
            a, b = np.where(mask, x, 0.), np.where(mask, y, 0.)
            event, _ = ratio(a, b)
            achunk, bchunk = a.reshape(50, -1).sum(axis=1), b.reshape(50, -1).sum(axis=1)
            chunk, influence = ratio(achunk, bchunk)
            curves = {key: float(val[mask].sum()) for key, val in weights.items()}
            z = weights['matched'] - weights['source']
            shift = z[mask].sum()/curves['source']
            signs = {label: dict(events=int(np.count_nonzero(mask & kind)), source_pb=float(w[mask & kind].sum()))
                     for label, kind in [('S_positive', ~h & (w > 0)), ('S_negative', ~h & (w < 0)), ('H_positive', h & (w > 0)), ('H_negative', h & (w < 0))]}
            scopes[name] = dict(events=int(mask.sum()), curves_pb=curves, matched_source_minus_one=float(shift),
                                transfers_event_error=event, transfers_50_chunk_error=chunk, signs=signs)
            components[cut, name] = influence
        report['cuts'][str(cut)] = scopes
    for name in ['all_selected', 'recoil5_20']:
        p25, p40 = report['cuts']['25'][name], report['cuts']['40'][name]
        report['paired_cut_changes'][name] = dict(ratio40_minus25=p40['transfers_50_chunk_error']['ratio']-p25['transfers_50_chunk_error']['ratio'],
             error=float(np.sqrt(50/49)*np.linalg.norm(components[40, name]-components[25, name])))
    independent = HERE.parent/'first/events.npz'
    if independent.is_file():
        new = np.load(independent)
        checks = dict(source_index_identical=np.array_equal(new['source_index'], np.arange(len(w))),
                      selected25_identical=np.array_equal(new['selected25'], masks[25]),
                      selected40_identical=np.array_equal(new['selected40'], masks[40]),
                      nominal_identical=np.array_equal(new['nominal'], w),
                      macnlops_identical=np.array_equal(new['macnlops'], m),
                      is_h_identical=np.array_equal(new['is_h'], h),
                      max_selected_recoil_difference=float(np.max(np.abs(new['fid_recoil'][fid25]-recoil[fid25]))),
                      max_selected_central_pt_difference=float(np.max(np.abs(new['central_jet_pt'][fid25]-central_pt[fid25]))))
        assert all(checks[key] for key in checks if key.endswith('_identical')), checks
        assert checks['max_selected_recoil_difference'] < 1e-8, checks
        assert checks['max_selected_central_pt_difference'] < 1e-8, checks
        report['exact_reclustering_crosscheck'] = checks
    (HERE/'first_identity.json').write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')
    for cut, scopes in report['cuts'].items():
        print(cut, scopes['recoil5_20']['transfers_event_error'], 'cross-section shift', scopes['recoil5_20']['matched_source_minus_one'])


if __name__ == '__main__':
    main()
