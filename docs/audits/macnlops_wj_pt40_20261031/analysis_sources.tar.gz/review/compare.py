"""Independent same-event cut and shower comparisons for the Wj sample."""
from pathlib import Path
import hashlib
import json
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
CURVES = ('source', 'matched', 'veto', 'removal')
SCOPES = ('all_selected', 'recoil5_20')


def sum_error(v):
    n = len(v)
    return float(np.sqrt(n/(n-1))*np.linalg.norm(v-v.mean()))


def ratio(a, b):
    A, B = float(a.sum()), float(b.sum())
    if A == 0:
        return None, None, None
    r = B/A
    influence = (b-r*a)/A
    error = float(np.sqrt(len(a)/(len(a)-1))*np.linalg.norm(influence))
    return r, error, influence


def main():
    first_path = ROOT/'first/events.npz'
    full_path = ROOT/'full/full_events.npz'
    first, full = np.load(first_path), np.load(full_path)
    n = len(first['nominal'])
    assert n == 1000000
    ids = np.arange(n)
    assert np.array_equal(first['source_index'], ids)
    assert np.array_equal(full['source_index'], ids)
    assert np.array_equal(full['job_index'], np.repeat(np.arange(50), 20000))
    obs25, obs40 = full['observables25'], full['observables40']
    sel25, sel40 = obs25[:, 12] > .5, obs40[:, 12] > .5
    unchanged = list(range(10))+[11]
    cut_checks = dict(first40_subset25=bool(np.all(~first['selected40'] | first['selected25'])),
                      full40_subset25=bool(np.all(~sel40 | sel25)),
                      full_raw_observables_identical=bool(np.array_equal(obs25[:, unchanged], obs40[:, unchanged])),
                      full_selected40_recoil_identical=bool(np.array_equal(obs25[sel40, 13], obs40[sel40, 13])),
                      full40_multiplicity_not_greater25=bool(np.all(obs40[:, 10] <= obs25[:, 10])))
    assert all(cut_checks.values()), cut_checks
    w, m, h = first['nominal'], first['macnlops'], first['is_h']
    w4 = np.column_stack([w, m, np.where(h, w, m), np.where(h, m, w)])
    weight_error = float(np.max(np.abs(w4-full['weights'])))
    assert np.allclose(w4, full['weights'], rtol=1e-12, atol=1e-12), weight_error
    assert np.max(np.abs(w4[:, 2]+w4[:, 3]-w4[:, 0]-w4[:, 1])) < 1e-12
    x, y = np.where(~h, w-m, 0.), np.where(h, m-w, 0.)
    expected_x = np.where(~h, w*(1.-first['keep']), 0.)
    expected_y = np.where(h, -w*(1.-first['keep']), 0.)
    signs = [('S_positive', ~h & (w > 0)), ('S_negative', ~h & (w < 0)),
             ('H_positive', h & (w > 0)), ('H_negative', h & (w < 0))]
    report = dict(events=n, jobs=50, events_per_contiguous_chunk=20000,
       method='Absolute signed event weights on the same original 1M endpoints and same-seed full showers. Selected totals are not renormalized. Primary errors use 50 paired contiguous chunks, with delta-method ratio influences; first-stage eventwise errors are also recorded for comparison to historical published figures.',
       expected_method='Stored first-emission keep probabilities average over the independent matching-decision RNG. All inputs were showered with their original nonzero nominal weights, so the same conditional expected transfer weights can be evaluated on full endpoints. These are separate from the realized four-weight production comparison.',
       limits='Conditional finite-event/shower errors exclude hard integration, beta-normalization and native trial-envelope uncertainties. The matching/gluon-denominator epoch is held fixed; only the analysis jet threshold changes.',
       inputs={str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in (first_path, full_path)},
       analysis_cut_identity_checks=cut_checks, weight_max_absolute_difference=weight_error,
       results={}, paired_cut_changes={}, paired_shower_changes={}, paired_change_of_shower_drift={})
    ratios = {}
    expected_ratios = {}
    net_chunks = {}
    for stage in ('first', 'full'):
        stage_result = {}
        for cut in (25, 40):
            if stage == 'first':
                selected = first[f'selected{cut}']
                recoil = first['fid_recoil']
            else:
                obs = full[f'observables{cut}']
                selected, recoil = obs[:, 12] > .5, obs[:, 13]
            cut_result = {}
            for scope in SCOPES:
                mask = selected if scope == 'all_selected' else selected & (recoil >= 5.) & (recoil < 20.)
                aa, bb = np.where(mask, x, 0.), np.where(mask, y, 0.)
                a, b = aa.reshape(50, -1).sum(axis=1), bb.reshape(50, -1).sum(axis=1)
                r, re, ri = ratio(a, b)
                event_r, event_re, _ = ratio(aa, bb)
                sums = np.array([np.where(mask, w4[:, k], 0.).reshape(50, -1).sum(axis=1) for k in range(4)])
                cs_r, cs_re, cs_i = ratio(sums[0], sums[1])
                assert abs((sums[1]-sums[0]).sum() - (b-a).sum()) < 1e-7
                composition = {}
                for label, kind in signs:
                    sm = mask & kind
                    composition[label] = dict(events=int(sm.sum()), source_pb=float(w[sm].sum()),
                                              S_transfer_pb=float(x[sm].sum()), H_transfer_pb=float(y[sm].sum()))
                n_s = composition['S_positive']['events']+composition['S_negative']['events']
                abs_s = composition['S_positive']['source_pb']-composition['S_negative']['source_pb']
                result = dict(events=int(mask.sum()),
                    curves_pb={name: dict(sum=float(sums[k].sum()), chunk_error=sum_error(sums[k])) for k, name in enumerate(CURVES)},
                    transfers=dict(S_pb=float(a.sum()), H_pb=float(b.sum()), net_pb=float((b-a).sum()), net_error=sum_error(b-a),
                                   ratio=r, chunk_error=re, event_error=event_re if stage == 'first' else None),
                    matched_source_minus_one=cs_r-1., matched_source_ratio_error=cs_re,
                    source_composition=composition,
                    negative_S_event_fraction=composition['S_negative']['events']/n_s if n_s else None,
                    negative_S_absolute_weight_fraction=-composition['S_negative']['source_pb']/abs_s if abs_s else None)
                ex, ey = np.where(mask, expected_x, 0.), np.where(mask, expected_y, 0.)
                er, ee, _ = ratio(ex, ey)
                ecx, ecy = ex.reshape(50, -1).sum(axis=1), ey.reshape(50, -1).sum(axis=1)
                _, ece, eri = ratio(ecx, ecy)
                emr, emre, emri = ratio(sums[0], sums[0]+ecy-ecx)
                result['expected_transfers'] = dict(S_pb=float(ex.sum()), H_pb=float(ey.sum()), net_pb=float((ey-ex).sum()),
                                                   ratio=er, event_error=ee if stage == 'first' else None, chunk_error=ece,
                                                   matched_source_minus_one=emr-1., matched_source_ratio_error=emre)
                expected_ratios[stage, cut, scope] = (er, eri, emr, emri)
                cut_result[scope] = result
                ratios[stage, cut, scope] = (r, ri, cs_r, cs_i)
                net_chunks[stage, cut, scope] = b-a
            stage_result[str(cut)] = cut_result
        report['results'][stage] = stage_result
    for stage in ('first', 'full'):
        report['paired_cut_changes'][stage] = {}
        for scope in SCOPES:
            r25, i25, c25, ci25 = ratios[stage, 25, scope]
            r40, i40, c40, ci40 = ratios[stage, 40, scope]
            dn = net_chunks[stage, 40, scope]-net_chunks[stage, 25, scope]
            report['paired_cut_changes'][stage][scope] = dict(ratio40_minus25=r40-r25,
                ratio_error=float(np.sqrt(50/49)*np.linalg.norm(i40-i25)),
                matched_source_ratio40_minus25=c40-c25,
                matched_source_ratio_error=float(np.sqrt(50/49)*np.linalg.norm(ci40-ci25)),
                net40_minus25_pb=float(dn.sum()), net_error=sum_error(dn))
            e25, ei25, ec25, eci25 = expected_ratios[stage, 25, scope]
            e40, ei40, ec40, eci40 = expected_ratios[stage, 40, scope]
            report['paired_cut_changes'][stage][scope]['expected'] = dict(ratio40_minus25=e40-e25,
                ratio_error=float(np.sqrt(50/49)*np.linalg.norm(ei40-ei25)),
                matched_source_ratio40_minus25=ec40-ec25,
                matched_source_ratio_error=float(np.sqrt(50/49)*np.linalg.norm(eci40-eci25)))
    for cut in (25, 40):
        report['paired_shower_changes'][str(cut)] = {}
        for scope in SCOPES:
            r1, i1, c1, ci1 = ratios['first', cut, scope]
            r2, i2, c2, ci2 = ratios['full', cut, scope]
            dn = net_chunks['full', cut, scope]-net_chunks['first', cut, scope]
            report['paired_shower_changes'][str(cut)][scope] = dict(full_minus_first=r2-r1,
                paired_error=float(np.sqrt(50/49)*np.linalg.norm(i2-i1)),
                matched_source_ratio_full_minus_first=c2-c1,
                matched_source_ratio_paired_error=float(np.sqrt(50/49)*np.linalg.norm(ci2-ci1)),
                net_full_minus_first_pb=float(dn.sum()), net_paired_error=sum_error(dn))
            e1, ei1, ec1, eci1 = expected_ratios['first', cut, scope]
            e2, ei2, ec2, eci2 = expected_ratios['full', cut, scope]
            report['paired_shower_changes'][str(cut)][scope]['expected'] = dict(full_minus_first=e2-e1,
                paired_error=float(np.sqrt(50/49)*np.linalg.norm(ei2-ei1)),
                matched_source_ratio_full_minus_first=ec2-ec1,
                matched_source_ratio_paired_error=float(np.sqrt(50/49)*np.linalg.norm(eci2-eci1)))
    for scope in SCOPES:
        r25a, i25a, _, _ = ratios['first', 25, scope]
        r25b, i25b, _, _ = ratios['full', 25, scope]
        r40a, i40a, _, _ = ratios['first', 40, scope]
        r40b, i40b, _, _ = ratios['full', 40, scope]
        report['paired_change_of_shower_drift'][scope] = dict(drift40_minus25=(r40b-r40a)-(r25b-r25a),
               error=float(np.sqrt(50/49)*np.linalg.norm(i40b-i40a-i25b+i25a)))
    (HERE/'comparison.json').write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')
    for stage in ('first', 'full'):
        for cut in ('25', '40'):
            row = report['results'][stage][cut]['recoil5_20']
            print(stage, cut, row['transfers'], 'relative shift', row['matched_source_minus_one'], '+/-', row['matched_source_ratio_error'])
    print('paired shower change40', report['paired_shower_changes']['40']['recoil5_20'])


if __name__ == '__main__':
    main()
