#!/usr/bin/env python3
"""Exact original-card full-shower replay, adding only analysis observables."""
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
import json,os,subprocess,time,hashlib
OUT=Path(__file__).resolve().parent
BASE=OUT.parents[1]
ORIGINAL=BASE/'processes/WPlusJet_5FS/MCatNLO/RUN_PYTHIA8_2'
ENV=dict(os.environ,PYTHIA8DATA='/nfs/home/rikkert/Downloads/pythia8/share/Pythia8/xmldoc',LD_LIBRARY_PATH='/nfs/home/rikkert/LHAPDF/lib:/nfs/home/rikkert/Downloads/pythia8/lib:/export/slow1/rikkert/MCcntRefactor_Sfun/HEPTools/hepmc/lib',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
def run(i):
    d=OUT/'jobs'/f'job_{i}';start=time.monotonic()
    if (d/'run.json').is_file():
        record=json.loads((d/'run.json').read_text())
        if record['exit_code']==0: return i,record
    with (d/'replay.log').open('w') as log:
        r=subprocess.run(['./Pythia8.exe'],cwd=d,env=ENV,stdout=log,stderr=subprocess.STDOUT)
    record=dict(exit_code=r.returncode,seconds=time.monotonic()-start)
    (d/'run.json').write_text(json.dumps(record)+'\n')
    if r.returncode:raise RuntimeError(f'Job{i} returned{r.returncode}')
    return i,record
if __name__=='__main__':
    original=ORIGINAL/'run_1/MADatNLO.HwU'
    pilot=OUT/'jobs/job_1/MADatNLO.HwU'
    assert original.read_bytes()==pilot.read_bytes(),'Pilot25GeV histogram changed'
    start=time.monotonic();done=[]
    with ThreadPoolExecutor(max_workers=32) as pool:
        for f in as_completed([pool.submit(run,i) for i in range(1,51)]):
            i,record=f.result();done.append(i);print(f'Completed job{i} ({len(done)}/50) in{record["seconds"]:.2f}s',flush=True)
    result=dict(jobs=50,events=1000000,seconds=time.monotonic()-start,environment={k:ENV[k] for k in ['PYTHIA8DATA','LD_LIBRARY_PATH','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS']})
    (OUT/'replay_summary.json').write_text(json.dumps(result,indent=2)+'\n')
