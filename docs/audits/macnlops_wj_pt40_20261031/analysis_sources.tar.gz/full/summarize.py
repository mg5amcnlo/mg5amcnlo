#!/usr/bin/env python3
"""Validate exact25GeV replay and export same-event25/40GeV full observables."""
from pathlib import Path
import hashlib,json,sys
import numpy as np
OUT=Path(__file__).resolve().parent
BASE=OUT.parents[1]
ORIGINAL=BASE/'processes/WPlusJet_5FS/MCatNLO/RUN_PYTHIA8_2'
RANGES=[(0,1),(1,2),(2,5),(5,10),(10,20),(5,20),(20,50),(50,100)]
FIELDS=json.loads((BASE/'analysis/observables.json').read_text())['fields']
def ratio_stats(x,y,jobs):
    a=np.bincount(jobs,weights=x,minlength=50);b=np.bincount(jobs,weights=y,minlength=50)
    A=float(a.sum());B=float(b.sum());N=50
    r=B/A if A else None
    err=float(np.sqrt(N/(N-1))*np.linalg.norm(b-r*a)/abs(A)) if A and r is not None else None
    diff=b-a
    return dict(S_pb=A,H_pb=B,ratio=r,error=err,net_H_minus_S_pb=float(diff.sum()),net_error_pb=float(np.sqrt(N/(N-1))*np.linalg.norm(diff-diff.mean())),S_by_job=a.tolist(),H_by_job=b.tolist())
def main():
    rows=[];verification=[]
    for i in range(1,51):
        d=OUT/'jobs'/f'job_{i}';r=json.loads((d/'run.json').read_text());assert r['exit_code']==0,(i,r)
        before=(ORIGINAL/f'run_{i}/MADatNLO.HwU').read_bytes();after=(d/'MADatNLO.HwU').read_bytes()
        assert before==after,('25GeV HwU changed',i)
        data=np.fromfile(d/'observables.bin',dtype=np.float64).reshape(-1,32)
        assert data.shape==(20000,32),(i,data.shape)
        rows.append(data)
        verification.append(dict(job=i,events=20000,original25_hwu_byte_identical=True,original25_hwu_sha256=hashlib.sha256(before).hexdigest(),replay25_hwu_sha256=hashlib.sha256(after).hexdigest(),observables_sha256=hashlib.sha256((d/'observables.bin').read_bytes()).hexdigest()))
    rows=np.concatenate(rows);o25=rows[:,:14];o40=rows[:,14:28];weights=rows[:,28:]
    original=np.load(BASE/'results/Wj_run_1M_native_ir_jets_lhe.npz')
    w,m,h=original['nominal'],original['macnlops'],original['is_h']
    expected=np.column_stack([w,m,np.where(h,w,m),np.where(h,m,w)])
    assert np.allclose(weights,expected,rtol=1e-14,atol=1e-15)
    s25=o25[:,12]>.5;s40=o40[:,12]>.5
    assert np.all(~s40|s25)
    assert np.array_equal(o25[s40,13],o40[s40,13])
    unchanged=[i for i in range(14) if i not in (10,12,13)]
    assert np.array_equal(o25[:,unchanged],o40[:,unchanged])
    jobs=np.repeat(np.arange(50,dtype=np.int16),20000)
    np.savez_compressed(OUT/'full_events.npz',source_index=np.arange(1000000),job_index=jobs,nominal=w,macnlops=m,is_h=h,selected25=s25,selected40=s40,fid_recoil=o25[:,13],w_pt=o25[:,6],raw_jet_pt=o25[:,7],raw_jet_y=o25[:,11],raw_recoil=o25[:,4],observables25=o25,observables40=o40,observable_names=np.array(FIELDS),weights=weights,weight_names=np.array(['source','matched','veto','removal']))
    x=np.where(~h,w-m,0.);y=np.where(h,m-w,0.);curves=dict(source=w,matched=m,veto=np.where(h,w,m),removal=np.where(h,m,w))
    report=dict(events=len(w),jobs=50,events_per_job=20000,original25_histograms_byte_identical=True,exact40_selection=True,selection_nested=True,selected40_recoil_unchanged=True,analysis_only_changed=True,source_or_matching_or_shower_settings_changed=False,max_weight_roundtrip_absolute_difference_pb=float(np.max(np.abs(weights-expected))),error_method='Conditional delta-method using 50 original contiguous 20k-event/shower chunks; all first/full and cut comparisons retain paired covariance. Original weights, no survivor normalization.',cuts={})
    histograms={};edges=np.linspace(0,100,101)
    for cut,selected in [(25,s25),(40,s40)]:
        totals={name:float(value[selected].sum()) for name,value in curves.items()}
        by_job={name:np.bincount(jobs,weights=np.where(selected,value,0.),minlength=50).tolist() for name,value in curves.items()}
        ranges=[]
        for lo,hi in RANGES:
            mask=selected&(o25[:,13]>=lo)&(o25[:,13]<hi)
            ranges.append(dict(lo=lo,hi=hi,events=int(mask.sum()),**ratio_stats(np.where(mask,x,0.),np.where(mask,y,0.),jobs)))
        report['cuts'][str(cut)]=dict(selected_events=int(selected.sum()),four_weight_totals_pb=totals,four_weight_totals_by_job_pb=by_job,matched_over_source=totals['matched']/totals['source'],matched_source_relative_shift=totals['matched']/totals['source']-1,transfers=ratio_stats(np.where(selected,x,0.),np.where(selected,y,0.),jobs),ranges=ranges,negative_S_events=int(np.sum(selected&~h&(w<0))),positive_S_events=int(np.sum(selected&~h&(w>0))),negative_H_events=int(np.sum(selected&h&(w<0))),positive_H_events=int(np.sum(selected&h&(w>0))))
        for name,value in curves.items():
            a=np.zeros((50,100))
            for j in range(50):
                mask=selected&(jobs==j)
                a[j]=np.histogram(o25[mask,13],bins=edges,weights=value[mask])[0]
            histograms[f'cut{cut}_{name}']=a
    np.savez_compressed(OUT/'histograms.npz',edges=edges,**histograms)
    (OUT/'summary.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    (OUT/'verification.json').write_text(json.dumps(dict(jobs=verification,passed=True,total_events=1000000),indent=2)+'\n')
    for cut in ['25','40']:
        r=report['cuts'][cut];rr=next(x for x in r['ranges'] if x['lo']==5 and x['hi']==20)
        print(cut,'selected',r['selected_events'],'H/S5-20',rr['ratio'],'+/-',rr['error'],'matched/source shift',r['matched_source_relative_shift'])
    print('All 50 original 25 GeV histograms byte-identical; 1M full-events npz written',flush=True)
if __name__=='__main__':main()
