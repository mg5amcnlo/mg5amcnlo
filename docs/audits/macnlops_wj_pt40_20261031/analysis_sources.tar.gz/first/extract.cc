// Reanalyse retained first-emission events. No event or shower modification.
#include "fjcore.hh"
#include <zlib.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

struct Input {
  gzFile f;
  char buffer[32768];
  explicit Input(const char* path): f(gzopen(path,"rb")) {
    if(!f) throw std::runtime_error("Cannot open input");
    gzbuffer(f,1<<20);
  }
  ~Input() {gzclose(f);}
  bool line(std::string& out) {
    out.clear();
    while(gzgets(f,buffer,sizeof(buffer))) {
      out+=buffer;
      if(!out.empty() && out.back()=='\n') return true;
    }
    if(gzeof(f)) return !out.empty();
    int code; const char* message=gzerror(f,&code);
    throw std::runtime_error(message);
  }
};

double attribute(const std::string& line,const std::string& key) {
  const auto pos=line.find(key+"=\"");
  if(pos==std::string::npos) throw std::runtime_error("Missing "+key);
  return std::stod(line.substr(pos+key.size()+2));
}

int main(int argc,char** argv) {
  try {
    if(argc!=3) throw std::runtime_error("Usage: extract INPUT.lhe.gz OUTPUT.bin");
    Input in(argv[1]); std::ofstream out(argv[2],std::ios::binary);
    if(!out) throw std::runtime_error("Cannot open output");
    fjcore::ClusterSequence::set_fastjet_banner_stream(nullptr);
    std::string line; size_t count=0; int maxPartons=0;
    while(in.line(line)) {
      if(line.rfind("<event",0)!=0) continue;
      if(!in.line(line)) throw std::runtime_error("Missing event header");
      std::istringstream header(line);
      int n,process; double weight;
      if(!(header>>n>>process>>weight)) throw std::runtime_error("Invalid header");
      std::vector<fjcore::PseudoJet> particles;
      double wx=0.,wy=0.;
      for(int i=0;i<n;++i) {
        if(!in.line(line)) throw std::runtime_error("Missing particle");
        std::istringstream row(line);
        int pdg,status,m1,m2,c1,c2; double px,py,pz,e;
        if(!(row>>pdg>>status>>m1>>m2>>c1>>c2>>px>>py>>pz>>e))
          throw std::runtime_error("Invalid particle");
        if(status!=1) continue;
        if((std::abs(pdg)<=5 || pdg==21) && e>0.) particles.emplace_back(px,py,pz,e);
        if(pdg==24) {wx=px;wy=py;}
      }
      maxPartons=std::max(maxPartons,int(particles.size()));
      int kind=0; double matched=0.,keep=-1.; bool sawWeight=false,closed=false;
      while(in.line(line)) {
        if(line.rfind("#aMCatNLO",0)==0) {std::istringstream row(line);std::string tag;row>>tag>>kind;}
        if(line.find("<wgt id='macnlops'>")!=std::string::npos) {
          matched=std::stod(line.substr(line.find('>')+1));sawWeight=true;
        }
        if(line.find("<macnlops_decision ")!=std::string::npos) keep=attribute(line,"keep");
        if(line.find("</event>")!=std::string::npos) {closed=true;break;}
      }
      if(!closed || !sawWeight || (kind!=1 && kind!=2) || !(keep>=0. && keep<=1.))
        throw std::runtime_error("Incomplete event annotations");
      if(particles.empty()) throw std::runtime_error("No QCD particle");
      fjcore::ClusterSequence cs(particles,fjcore::JetDefinition(fjcore::antikt_algorithm,.5));
      const auto all=fjcore::sorted_by_pt(cs.inclusive_jets(0.));
      std::vector<fjcore::PseudoJet> central;
      for(const auto& jet:all) if(std::abs(jet.rap())<4.5) central.push_back(jet);
      // Central-leading jet is independent of the later25/40 threshold.
      const double centralPt=central.empty()?0.:central[0].perp();
      const double centralY=central.empty()?0.:central[0].rap();
      const double centralRecoil=central.empty()?0.:std::hypot(wx+central[0].px(),wy+central[0].py());
      const double central2Pt=central.size()>1?central[1].perp():0.;
      const double rawRecoil=std::hypot(wx+all[0].px(),wy+all[0].py());
      int n25=0,n40=0;
      for(const auto& jet:central) {n25+=jet.perp()>25.;n40+=jet.perp()>40.;}
      const std::array<double,16> values{{weight,matched,double(kind),keep,centralPt,centralY,
        centralRecoil,all[0].perp(),all[0].rap(),rawRecoil,std::hypot(wx,wy),central2Pt,
        double(n25),double(n40),double(particles.size()),double(all.size())}};
      for(double value:values) if(!std::isfinite(value)) throw std::runtime_error("Nonfinite observable");
      out.write(reinterpret_cast<const char*>(values.data()),sizeof(values));
      if(!out) throw std::runtime_error("Output failure");
      ++count;
      if(count%100000==0) std::cerr<<count<<" events\n";
    }
    std::cout<<"events="<<count<<" maximum_final_QCD_partons="<<maxPartons<<"\n";
    return 0;
  } catch(const std::exception& e) {std::cerr<<e.what()<<"\n";return 1;}
}
