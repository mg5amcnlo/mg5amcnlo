#!/usr/bin/env python3
"""Exact first-emission25/40GeV cut comparison on the original1M Wj sample."""
from pathlib import Path
import hashlib
import json
import numpy as np

BASE=Path('/export/slow1/rikkert/macnlops_native_ir_jets_1M_20261031')
OUT=Path(__file__).resolve().parent
SOURCE=BASE/'processes/WPlusJet_5FS/Events/run_1M_native_ir_jets/events.lhe.gz'
OLD=BASE/'results/Wj_run_1M_native_ir_jets_lhe.npz'
RANGES=[(0,1),(1,2),(2,5),(5,10),(10,20),(5,20),(20,50),(50,100),(0,100),(0,None)]

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for data in iter(lambda:f.read(1<<20),b''): h.update(data)
    return h.hexdigest()

def chunks(x):
    return x.reshape(50,20000).sum(axis=1)

def ratio_stat(x,y):
    X,Y=float(x.sum()),float(y.sum())
    if X==0: return dict(S_pb=X,H_pb=Y,ratio=None,event_error=None,chunk_error=None)
    ratio=Y/X
    influence=(y-ratio*x)/X
    ci=chunks(influence)
    return dict(S_pb=X,H_pb=Y,ratio=ratio,event_error=float(np.linalg.norm(influence)),
                chunk_error=float(np.sqrt(50/49)*np.linalg.norm(ci)))

def mean_error(x):
    c=chunks(x)
    return dict(value_pb=float(x.sum()),event_error_pb=float(np.linalg.norm(x)),
                chunk_error_pb=float(np.sqrt(50/49)*np.linalg.norm(c-c.mean())))

def main():
    rows=np.fromfile(OUT/'events.bin',dtype=np.float64).reshape(-1,16)
    assert rows.shape==(1000000,16),rows.shape
    old=np.load(OLD)
    cols={name:i for i,name in enumerate(old['observable_names'])}
    w,m,h,keep=rows[:,0],rows[:,1],rows[:,2]==2,rows[:,3]
    assert np.array_equal(w,old['nominal'])
    assert np.array_equal(m,old['macnlops'])
    assert np.array_equal(h,old['is_h'])
    obs=old['observables']
    comparisons={}
    for name,col in [('jet1_pt',7),('jet1_y',8),('primary_scale',9),('w_pt',10),('jet2_pt',11),('nfidjets',12)]:
        diff=np.abs(rows[:,col]-obs[:,cols[name]])
        comparisons[name]=float(diff.max())
        assert np.allclose(rows[:,col],obs[:,cols[name]],rtol=2e-14,atol=1e-11),(name,diff.max())
    select25=rows[:,4]>25
    select40=rows[:,4]>40
    assert np.array_equal(select25,obs[:,cols['fiducial']]>0.5)
    assert np.array_equal(select25,rows[:,12]>0)
    assert np.array_equal(select40,rows[:,13]>0)
    comparisons['fid_recoil']=float(np.max(np.abs(rows[select25,6]-obs[select25,cols['fid_primary_scale']])))
    assert np.allclose(rows[select25,6],obs[select25,cols['fid_primary_scale']],rtol=2e-14,atol=1e-11)
    assert np.all(~select40|select25)
    np.savez_compressed(OUT/'events.npz',source_index=np.arange(len(rows)),
        central_jet_pt=rows[:,4],central_jet_y=rows[:,5],fid_recoil=rows[:,6],
        raw_jet_pt=rows[:,7],raw_jet_y=rows[:,8],raw_recoil=rows[:,9],w_pt=rows[:,10],
        central_jet2_pt=rows[:,11],nfid25=rows[:,12].astype(np.int16),nfid40=rows[:,13].astype(np.int16),
        nominal=w,macnlops=m,is_h=h,keep=keep,selected25=select25,selected40=select40)
    mode_weights={'realized':m,'expected':w*keep}
    weights={mode:dict(source=w,veto=np.where(h,w,a),removal=np.where(h,a,w),matched=a)
             for mode,a in mode_weights.items()}
    transfer={mode:(np.where(~h,w-a,0),np.where(h,a-w,0)) for mode,a in mode_weights.items()}
    report=dict(events=len(rows),selection='At least one anti-kT R=0.5 jet withpT>threshold and|y|<4.5, E-scheme; recoil=W+leadingpassingjet.',
        epoch='Original1M Wj production: old denominator, unchanged source weights/decisions/endpoints; isolate analysis cut only.',
        normalization='Original signed event weights; no survivor, fiducial or range normalization.',
        uncertainty='Conditional eventwise and paired50x20000source-chunk delta-method sampling errors. Hard integration, beta and native-envelope effects excluded.',
        independent_original_observable_max_errors=comparisons,max_final_qcd_partons=int(rows[:,14].max()),
        max_clustered_jets=int(rows[:,15].max()),cuts={},paired40_minus25={})
    hist={}
    for threshold,selected in [(25,select25),(40,select40)]:
        cut=dict(selected_events=int(selected.sum()),classes={},ranges=[])
        for label,mask in [('S+',~h&(w>0)),('S-',~h&(w<0)),('H+',h&(w>0)),('H-',h&(w<0))]:
            mask=mask&selected
            cut['classes'][label]=dict(events=int(mask.sum()),source_pb=float(w[mask].sum()),
                source_absolute_pb=float(np.abs(w[mask]).sum()),matched_pb=float(m[mask].sum()),
                expected_matched_pb=float((w*keep)[mask].sum()))
        s=selected&~h
        cut['negative_S_event_fraction']=float(np.count_nonzero(s&(w<0))/np.count_nonzero(s))
        cut['negative_S_absolute_weight_fraction']=float(-w[s&(w<0)].sum()/np.abs(w[s]).sum())
        for lo,hi in RANGES:
            mask=selected&(rows[:,6]>=lo)
            if hi is not None: mask&=rows[:,6]<hi
            row=dict(lo=lo,hi=hi,events=int(mask.sum()),modes={})
            for mode,(X,Y) in transfer.items():
                x,y=np.where(mask,X,0),np.where(mask,Y,0)
                stats=ratio_stat(x,y)
                stats['net_H_minus_S']=mean_error(y-x)
                source=np.where(mask,w,0)
                matched=np.where(mask,mode_weights[mode],0)
                W,M=float(source.sum()),float(matched.sum())
                relative=M/W-1 if W else None
                stats['source_pb']=W;stats['matched_pb']=M
                stats['matched_over_source_minus1']=relative
                if W:
                    influence=(matched-(M/W)*source)/W
                    stats['matched_over_source_event_error']=float(np.linalg.norm(influence))
                    stats['matched_over_source_chunk_error']=float(np.sqrt(50/49)*np.linalg.norm(chunks(influence)))
                stats['chunks']={name:chunks(np.where(mask,a,0)).tolist() for name,a in weights[mode].items()}
                row['modes'][mode]=stats
            cut['ranges'].append(row)
        report['cuts'][str(threshold)]=cut
        for field,edges in [('fid_recoil',np.arange(0,101.)),('w_pt',np.linspace(0,500,101)),('central_jet_pt',np.linspace(0,500,101))]:
            coordinate=rows[:,{'fid_recoil':6,'w_pt':10,'central_jet_pt':4}[field]]
            for mode,curves in weights.items():
                for name,value in curves.items():
                    key=f'cut{threshold}_{mode}_{field}_{name}'
                    hist[key]=np.histogram(coordinate[selected],bins=edges,weights=value[selected])[0]
                    hist[key+'_sumw2']=np.histogram(coordinate[selected],bins=edges,weights=value[selected]**2)[0]
            hist[field+'_edges']=edges
    for lo,hi in RANGES:
        key=f'{lo}_{hi}'
        paired={}
        masks=[]
        for selected in [select25,select40]:
            mask=selected&(rows[:,6]>=lo)
            if hi is not None:mask&=rows[:,6]<hi
            masks.append(mask)
        for mode,(X,Y) in transfer.items():
            influences=[];ratios=[]
            for mask in masks:
                x=np.where(mask,X,0);y=np.where(mask,Y,0)
                r=y.sum()/x.sum();ratios.append(float(r))
                influences.append((y-r*x)/x.sum())
            delta=influences[1]-influences[0]
            netdelta=np.where(masks[1],Y-X,0)-np.where(masks[0],Y-X,0)
            paired[mode]=dict(ratio25=ratios[0],ratio40=ratios[1],ratio_difference=ratios[1]-ratios[0],
                paired_event_error=float(np.linalg.norm(delta)),paired_chunk_error=float(np.sqrt(50/49)*np.linalg.norm(chunks(delta))),
                net_difference=mean_error(netdelta))
        report['paired40_minus25'][key]=paired
    np.savez_compressed(OUT/'histograms.npz',**hist)
    (OUT/'summary.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    provenance=dict(inputs={str(path):dict(bytes=path.stat().st_size,sha256=sha(path)) for path in [SOURCE,OLD,
        OUT/'extract.cc',OUT/'extract',OUT/'analyse.py',BASE/'processes/WPlusJet_5FS/SubProcesses/fjcore.cc',BASE/'processes/WPlusJet_5FS/SubProcesses/fjcore.hh']},
        build_command='g++ -O2 -std=c++17 -I BASE/processes/WPlusJet_5FS/SubProcesses extract.cc BASE/processes/WPlusJet_5FS/SubProcesses/fjcore.cc -lz -o extract',
        extraction_command=[str(OUT/'extract'),str(SOURCE),str(OUT/'events.bin')],
        outputs={name:dict(bytes=(OUT/name).stat().st_size,sha256=sha(OUT/name)) for name in ['events.npz','summary.json','histograms.npz']})
    (OUT/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
    for threshold in ['25','40']:
        row=next(x for x in report['cuts'][threshold]['ranges'] if x['lo']==5 and x['hi']==20)
        print(threshold,report['cuts'][threshold]['selected_events'],json.dumps(row['modes'],indent=2)[:2200])

if __name__=='__main__': main()
