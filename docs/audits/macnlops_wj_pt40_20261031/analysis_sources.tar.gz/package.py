"""Retain a compact, explicitly bound record of the Wj cut-only comparison."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = Path('/export/slow1/rikkert/MCcntRefactor_Sfun_MacNLOPS')
DEST = ROOT / 'docs/audits/macnlops_wj_pt40_20261031'

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()

def binding(path):
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest(path))

def main():
    DEST.mkdir(parents=True, exist_ok=True)
    files = {
        'report.md': 'report.md',
        'comparison.json': 'review/comparison.json',
        'validation/first.json': 'first/summary.json',
        'validation/full.json': 'full/summary.json',
        'validation/original_25GeV_replay.json': 'full/verification.json',
        'validation/first_independent.json': 'review/first_identity.json',
        'provenance/first.json': 'first/provenance.json',
        'provenance/full.json': 'full/provenance.json',
        'provenance/full_build.json': 'full/build_manifest.json',
        'provenance/full_inputs.json': 'full/input_manifest.json',
        'provenance/full_jobs.json': 'full/run_manifest.json',
        'plots/wj_analysis_pt40.pdf': 'plots/wj_analysis_pt40.pdf',
        'plots/wj_pt40_four_weights.png': 'plots/wj_pt40_four_weights.png',
        'plots/wj_pt40_transfers.png': 'plots/wj_pt40_transfers.png',
        'plots/histograms.json': 'plots/wj_pt40_histograms.json',
    }
    normalized = {}
    for name, relative in files.items():
        source, target = BASE / relative, DEST / name
        target.parent.mkdir(parents=True, exist_ok=True)
        if source.suffix == '.json':
            obj = json.loads(source.read_text())
            target.write_text(json.dumps(obj, separators=(',', ':'), allow_nan=False) + '\n')
            assert json.loads(target.read_text()) == obj
            normalized[name] = dict(original=binding(source), operation='JSON whitespace only')
        else:
            shutil.copy2(source, target)
    sources = [
        'first/extract.cc', 'first/analyse.py',
        'full/run_replay.py', 'full/summarize.py',
        'full/build/Pythia83.cc', 'full/build/jet_observables.cc',
        'full/build/jet_observables40.cc', 'full/build/py8an_HwU_jetvalidation.f',
        'review/check_first.py', 'review/compare.py', 'plot.py', 'package.py',
    ]
    archive = DEST / 'analysis_sources.tar.gz'
    with tarfile.open(archive, 'w:gz') as output:
        for name in sources:
            output.add(BASE / name, arcname=name)
    with tarfile.open(archive) as check:
        for name in sources:
            assert hashlib.sha256(check.extractfile(name).read()).hexdigest() == digest(BASE / name)
    readme = '''W+jet analysis jet threshold 25 -> 40 GeV, 31 October 2026

Same original 1M source/matching events and 50 same-stream shower jobs.
Only the analysis threshold changes. Generation remains pT>20 GeV,
anti-kT R=0.5; analysis keeps |y|<4.5. No signed-weight renormalization.
The matching epoch precedes the global-gluon denominator correction.

report.md explains the result. comparison.json contains paired statistics;
plots/ contains the two-page PDF, previews and numerical plot data.
validation/ records exact reclustering and byte-identical original 25 GeV
histograms for all 50 shower jobs. provenance/ binds inputs and builds.
analysis_sources.tar.gz contains the exact scripts and analysis sources.
JSON copies are whitespace-compacted; original hashes remain recorded.

All large per-event arrays, inputs, builds and logs remain at:
/export/slow1/rikkert/macnlops_native_ir_jets_1M_20261031/wj_analysis_pt40_20261031
No production events, matching decisions, Pythia source or libraries were changed.
'''
    (DEST / 'README.txt').write_text(readme)
    external_names = ['first/events.npz', 'first/events.bin', 'first/histograms.npz',
                      'full/full_events.npz', 'full/histograms.npz', 'full/replay_summary.json']
    record = dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  campaign=str(BASE), events=1000000, shower_jobs=50,
                  cut_only=True, old_matching_epoch_retained=True,
                  production_or_pythia_modified=False,
                  external_files={name: binding(BASE / name) for name in external_names},
                  archived_sources={name: binding(BASE / name) for name in sources},
                  normalized_files=normalized,
                  retained_files={str(p.relative_to(DEST)): binding(p)
                                  for p in sorted(DEST.rglob('*'))
                                  if p.is_file() and p.name != 'snapshot.json'})
    (DEST / 'snapshot.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print('Retained', len(record['retained_files']), 'files;',
          sum(v['bytes'] for v in record['retained_files'].values()), 'bytes')

if __name__ == '__main__':
    main()
